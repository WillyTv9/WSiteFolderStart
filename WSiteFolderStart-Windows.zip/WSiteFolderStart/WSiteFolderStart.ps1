﻿# WSiteFolderStart - app per Windows (PowerShell + WPF)
# Nessuna dipendenza: usa solo ciò che c'è già in Windows 10/11.
# Stesso layout, stesse impostazioni e stessi testi della versione macOS.
# Il "vetro" della scheda è un vero sfondo sfocato (blur dello sfondo dell'app + velo + bordo luminoso).
#
# Avvio:  powershell -STA -ExecutionPolicy Bypass -File WSiteFolderStart.ps1
#         (oppure doppio clic su WSiteFolderStart.vbs, che nasconde la console)
# Test:   ... -File WSiteFolderStart.ps1 -SelfTest    (costruisce le finestre senza mostrarle)

param([switch]$SelfTest)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase, System.Windows.Forms, System.Drawing, Microsoft.VisualBasic

$script:AppName = 'WSiteFolderStart'

# ---------------------------------------------------------------------------
# Percorsi e log
# ---------------------------------------------------------------------------

# $PSScriptRoot è vuoto se lo script è compilato in .exe (ps2exe): si usa la cartella dell'eseguibile
$script:Here = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent ([System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName) }
$script:LogDir = Join-Path $env:LOCALAPPDATA $script:AppName
$script:LogFile = Join-Path $script:LogDir "$($script:AppName).log"

function Initialize-Log {
    try {
        [void](New-Item -ItemType Directory -Force -Path $script:LogDir)
        Set-Content -Path $script:LogFile -Value '' -Encoding UTF8
    } catch { }
}
function Write-Log([string]$Message) {
    try { Add-Content -Path $script:LogFile -Value ('{0:s} {1}' -f (Get-Date), $Message) -Encoding UTF8 } catch { }
}

# Cerca una cartella di risorse accanto allo script (versione distribuita)
# oppure un livello sopra (dentro la repo: windows\ + assets\ e templates\)
function Find-Dir([string]$Name) {
    foreach ($c in @((Join-Path $script:Here $Name), (Join-Path (Split-Path -Parent $script:Here) $Name))) {
        if (Test-Path -LiteralPath $c -PathType Container) { return $c }
    }
    throw "Cartella '$Name' non trovata accanto all'app"
}

# ---------------------------------------------------------------------------
# Impostazioni (salvate automaticamente in %APPDATA%\WSiteFolderStart\settings.json)
# ---------------------------------------------------------------------------

$script:SettingsDir = Join-Path $env:APPDATA $script:AppName
$script:SettingsFile = Join-Path $script:SettingsDir 'settings.json'
$script:Settings = @{ dest = 'desktop'; customPath = ''; closeAfter = $true; reveal = $false; template = $false }

function Import-Settings {
    if (-not (Test-Path -LiteralPath $script:SettingsFile)) { return }
    try {
        $json = Get-Content -LiteralPath $script:SettingsFile -Raw | ConvertFrom-Json
        foreach ($k in @($script:Settings.Keys)) {
            if ($null -ne $json.$k) { $script:Settings[$k] = $json.$k }
        }
    } catch { Write-Log "impostazioni non leggibili: $_" }
}
function Save-Settings {
    try {
        [void](New-Item -ItemType Directory -Force -Path $script:SettingsDir)
        $script:Settings | ConvertTo-Json | Set-Content -LiteralPath $script:SettingsFile -Encoding UTF8
    } catch { Write-Log "impostazioni non salvate: $_" }
}

function Get-DownloadsPath {
    try {
        $p = (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
        if ($p) { return $p }
    } catch { }
    return (Join-Path $env:USERPROFILE 'Downloads')
}
function Get-DestPath {
    switch ($script:Settings.dest) {
        'documents' { return [Environment]::GetFolderPath('MyDocuments') }
        'downloads' { return (Get-DownloadsPath) }
        'custom'    { if ($script:Settings.customPath) { return $script:Settings.customPath } }
    }
    return [Environment]::GetFolderPath('Desktop')
}
function Get-DestName {
    switch ($script:Settings.dest) {
        'documents' { return 'Documenti' }
        'downloads' { return 'Download' }
        'custom' {
            if ($script:Settings.customPath) {
                $leaf = Split-Path -Leaf $script:Settings.customPath
                if ($leaf) { return $leaf } else { return $script:Settings.customPath }
            }
        }
    }
    return 'Scrivania'
}

# ---------------------------------------------------------------------------
# Creazione della struttura
# ---------------------------------------------------------------------------

function Get-CleanName([string]$Raw) {
    $n = $Raw -replace '[\\/:*?"<>|]', ''   # caratteri non ammessi nei nomi di cartella
    $n = $n -replace '^[\s.]+', ''
    $n = $n -replace '[\s.]+$', ''
    return $n
}

# Crea Html/Css/Php/Js/Img e i quattro file. Non sovrascrive mai file già esistenti.
function New-SiteFolder([string]$Root, [bool]$UseTemplate, [string]$TemplatesDir) {
    foreach ($d in 'Html', 'Css', 'Php', 'Js', 'Img') {
        [void](New-Item -ItemType Directory -Force -Path (Join-Path $Root $d))
    }
    $files = @(@('Html', 'index.html'), @('Css', 'style.css'), @('Php', 'login.php'), @('Js', 'script.js'))
    foreach ($f in $files) {
        $dst = Join-Path (Join-Path $Root $f[0]) $f[1]
        if (Test-Path -LiteralPath $dst) { continue }
        if ($UseTemplate) { Copy-Item -LiteralPath (Join-Path $TemplatesDir $f[1]) -Destination $dst }
        else { [void](New-Item -ItemType File -Path $dst) }
    }
}

# ---------------------------------------------------------------------------
# Tema chiaro / scuro (segue Windows) e barra del titolo
# ---------------------------------------------------------------------------

function Test-DarkMode {
    try {
        $v = Get-ItemPropertyValue -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' -Name 'AppsUseLightTheme'
        return ($v -eq 0)
    } catch { return $false }
}

$script:Palette = @{
    Light = @{
        Fg = '#1C2630'; Fg2 = '#59636E'; Fg3 = '#8A949E'; ErrorFg = '#D70015'
        CardFill = '#59FFFFFF'; EdgeA = '#E6FFFFFF'; EdgeB = '#33FFFFFF'
        FieldFill = '#A6FFFFFF'; FieldBorder = '#2E000000'; SettingsBg = '#F5F5F7'
    }
    Dark = @{
        Fg = '#F2F5F7'; Fg2 = '#B4BEC6'; Fg3 = '#808B94'; ErrorFg = '#FF6961'
        CardFill = '#2EFFFFFF'; EdgeA = '#70FFFFFF'; EdgeB = '#14FFFFFF'
        FieldFill = '#38000000'; FieldBorder = '#2EFFFFFF'; SettingsBg = '#1F2125'
    }
}

if (-not ('Win32.Dwm' -as [type])) {
    Add-Type -Namespace Win32 -Name Dwm -MemberDefinition '[DllImport("dwmapi.dll")] public static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int attrValue, int attrSize);'
}

# Barra del titolo scura quando Windows è in tema scuro (Windows 10 build 18985+ e Windows 11)
function Set-TitleBar($Window, [bool]$Dark) {
    try {
        $h = (New-Object System.Windows.Interop.WindowInteropHelper($Window)).Handle
        if ($h -eq [IntPtr]::Zero) { return }
        $v = [int]$Dark
        [void][Win32.Dwm]::DwmSetWindowAttribute($h, 20, [ref]$v, 4)   # DWMWA_USE_IMMERSIVE_DARK_MODE
    } catch { Write-Log "barra del titolo: $_" }
}

function ConvertTo-Brush([string]$Hex) {
    return [System.Windows.Media.BrushConverter]::new().ConvertFromString($Hex)
}
function New-EdgeBrush([string]$A, [string]$B) {
    $g = New-Object System.Windows.Media.LinearGradientBrush
    $g.StartPoint = [System.Windows.Point]::new(0, 0)
    $g.EndPoint = [System.Windows.Point]::new(1, 1)
    [void]$g.GradientStops.Add([System.Windows.Media.GradientStop]::new([System.Windows.Media.ColorConverter]::ConvertFromString($A), 0.0))
    [void]$g.GradientStops.Add([System.Windows.Media.GradientStop]::new([System.Windows.Media.ColorConverter]::ConvertFromString($B), 1.0))
    return $g
}
function Set-ThemeResources($Window, [hashtable]$P) {
    foreach ($k in $P.Keys) {
        if ($k -like 'Edge*') { continue }
        $Window.Resources[$k] = ConvertTo-Brush $P[$k]
    }
    $Window.Resources['CardEdge'] = New-EdgeBrush $P.EdgeA $P.EdgeB
}

function Update-Theme {
    $dark = Test-DarkMode
    if ($null -ne $script:DarkShown -and $dark -eq $script:DarkShown) { return }
    $script:DarkShown = $dark
    $p = if ($dark) { $script:Palette.Dark } else { $script:Palette.Light }
    $img = if ($dark) { $script:BgDark } else { $script:BgLight }

    Set-ThemeResources $script:Win $p
    $script:UI.Bg.Source = $img
    $script:UI.BgBlur.Source = $img
    Set-TitleBar $script:Win $dark
    if ($script:SettingsWin) {
        Set-ThemeResources $script:SettingsWin $p
        Set-TitleBar $script:SettingsWin $dark
    }
}

# ---------------------------------------------------------------------------
# Interfaccia (XAML). Le coordinate sono le stesse della versione macOS,
# già convertite per avere l'origine in alto a sinistra.
# ---------------------------------------------------------------------------

$script:MainXaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="WSiteFolderStart" SizeToContent="WidthAndHeight" ResizeMode="CanMinimize"
        WindowStartupLocation="CenterScreen" UseLayoutRounding="True"
        FontFamily="Segoe UI Variable Text, Segoe UI">
  <Window.Resources>
    <SolidColorBrush x:Key="Fg" Color="#1C2630"/>
    <SolidColorBrush x:Key="Fg2" Color="#59636E"/>
    <SolidColorBrush x:Key="Fg3" Color="#8A949E"/>
    <SolidColorBrush x:Key="ErrorFg" Color="#D70015"/>
    <SolidColorBrush x:Key="CardFill" Color="#59FFFFFF"/>
    <SolidColorBrush x:Key="CardEdge" Color="#66FFFFFF"/>
    <SolidColorBrush x:Key="FieldFill" Color="#A6FFFFFF"/>
    <SolidColorBrush x:Key="FieldBorder" Color="#2E000000"/>

    <Style x:Key="Field" TargetType="TextBox">
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="TextBox">
            <Border x:Name="Bd" CornerRadius="9" BorderThickness="1"
                    BorderBrush="{DynamicResource FieldBorder}" Background="{DynamicResource FieldFill}">
              <ScrollViewer x:Name="PART_ContentHost" Margin="9,0" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsKeyboardFocused" Value="True">
                <Setter TargetName="Bd" Property="BorderBrush" Value="#218C99"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style x:Key="Primary" TargetType="Button">
      <Setter Property="Foreground" Value="White"/>
      <Setter Property="FontSize" Value="16"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border x:Name="Bd" CornerRadius="19" Background="#218C99" BorderBrush="#73FFFFFF" BorderThickness="1">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="Bd" Property="Background" Value="#27A0AE"/></Trigger>
              <Trigger Property="IsPressed" Value="True"><Setter TargetName="Bd" Property="Background" Value="#1B7480"/></Trigger>
              <Trigger Property="IsEnabled" Value="False"><Setter TargetName="Bd" Property="Opacity" Value="0.6"/></Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style x:Key="Flat" TargetType="Button">
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border Background="Transparent">
              <ContentPresenter x:Name="Cp" HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="Cp" Property="Opacity" Value="0.6"/></Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>
  </Window.Resources>

  <Canvas Width="440" Height="520">
    <Image x:Name="Bg" Width="440" Height="520" Stretch="Fill"/>
    <Image x:Name="Logo" Canvas.Left="145" Canvas.Top="8" Width="150" Height="150" Stretch="Uniform"/>
    <TextBlock Canvas.Top="160" Width="440" Height="36" Text="App in esecuzione" TextAlignment="Center"
               FontSize="28" FontWeight="SemiBold" Foreground="{DynamicResource Fg}"/>
    <TextBlock Canvas.Top="202" Width="440" Text="Prepara in un attimo la struttura del tuo sito" TextAlignment="Center"
               FontSize="13" Foreground="{DynamicResource Fg2}"/>

    <!-- Scheda di vetro: copia sfocata dello sfondo, allineata alla finestra, ritagliata ad angoli arrotondati -->
    <Grid Canvas.Left="30" Canvas.Top="236" Width="380" Height="200">
      <Grid.Clip><RectangleGeometry Rect="0,0,380,200" RadiusX="26" RadiusY="26"/></Grid.Clip>
      <Image x:Name="BgBlur" Width="440" Height="520" Stretch="Fill"
             HorizontalAlignment="Left" VerticalAlignment="Top" Margin="-30,-236,0,0">
        <Image.Effect><BlurEffect Radius="32" KernelType="Gaussian"/></Image.Effect>
      </Image>
      <Border Background="{DynamicResource CardFill}"/>
      <Border CornerRadius="26" BorderThickness="1.2" BorderBrush="{DynamicResource CardEdge}"/>
    </Grid>

    <Canvas Canvas.Left="30" Canvas.Top="236" Width="380" Height="200">
      <TextBlock Canvas.Left="22" Canvas.Top="18" Width="336" Text="Inserisci nome cartella principale"
                 FontSize="12" FontWeight="SemiBold" Foreground="{DynamicResource Fg2}"/>
      <TextBox x:Name="Field" Canvas.Left="22" Canvas.Top="38" Width="336" Height="30" FontSize="15" MaxLength="120"
               Style="{StaticResource Field}" Foreground="{DynamicResource Fg}" CaretBrush="{DynamicResource Fg}"/>
      <TextBlock x:Name="Placeholder" Canvas.Left="32" Canvas.Top="43" Text="es. MioSito" FontSize="15"
                 Foreground="{DynamicResource Fg3}" IsHitTestVisible="False"/>
      <TextBlock x:Name="ErrorLbl" Canvas.Top="74" Width="380" TextAlignment="Center" FontSize="11"
                 Foreground="{DynamicResource ErrorFg}"/>
      <Button x:Name="CreateBtn" Canvas.Left="22" Canvas.Top="100" Width="336" Height="38" Content="Scatena"
              IsDefault="True" Style="{StaticResource Primary}"/>

      <Border Canvas.Left="23"  Canvas.Top="156" Width="58" Height="24" CornerRadius="12" Background="#38FF9500">
        <TextBlock Text="Html" FontSize="12" FontWeight="SemiBold" HorizontalAlignment="Center" VerticalAlignment="Center" Foreground="{DynamicResource Fg}"/></Border>
      <Border Canvas.Left="92"  Canvas.Top="156" Width="58" Height="24" CornerRadius="12" Background="#38007AFF">
        <TextBlock Text="Css" FontSize="12" FontWeight="SemiBold" HorizontalAlignment="Center" VerticalAlignment="Center" Foreground="{DynamicResource Fg}"/></Border>
      <Border Canvas.Left="161" Canvas.Top="156" Width="58" Height="24" CornerRadius="12" Background="#38AF52DE">
        <TextBlock Text="Php" FontSize="12" FontWeight="SemiBold" HorizontalAlignment="Center" VerticalAlignment="Center" Foreground="{DynamicResource Fg}"/></Border>
      <Border Canvas.Left="230" Canvas.Top="156" Width="58" Height="24" CornerRadius="12" Background="#38FFCC00">
        <TextBlock Text="Js" FontSize="12" FontWeight="SemiBold" HorizontalAlignment="Center" VerticalAlignment="Center" Foreground="{DynamicResource Fg}"/></Border>
      <Border Canvas.Left="299" Canvas.Top="156" Width="58" Height="24" CornerRadius="12" Background="#3834C759">
        <TextBlock Text="Img" FontSize="12" FontWeight="SemiBold" HorizontalAlignment="Center" VerticalAlignment="Center" Foreground="{DynamicResource Fg}"/></Border>
    </Canvas>

    <Button x:Name="CaptionBtn" Canvas.Left="60" Canvas.Top="444" Width="320" Height="20" FontSize="12"
            Style="{StaticResource Flat}" Foreground="{DynamicResource Fg2}" ToolTip="Cambia le impostazioni"/>
    <Button x:Name="GearBtn" Canvas.Left="390" Canvas.Top="42" Width="30" Height="30"
            Style="{StaticResource Flat}" Foreground="{DynamicResource Fg2}" ToolTip="Impostazioni  (Ctrl+,)">
      <TextBlock FontFamily="Segoe Fluent Icons, Segoe MDL2 Assets" Text="&#xE713;" FontSize="16"/>
    </Button>
  </Canvas>
</Window>
'@

$script:SettingsXaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Impostazioni" Width="420" SizeToContent="Height" ResizeMode="NoResize"
        ShowInTaskbar="False" WindowStartupLocation="CenterOwner"
        FontFamily="Segoe UI Variable Text, Segoe UI" FontSize="13"
        Background="{DynamicResource SettingsBg}" Foreground="{DynamicResource Fg}">
  <Window.Resources>
    <SolidColorBrush x:Key="SettingsBg" Color="#F5F5F7"/>
    <SolidColorBrush x:Key="Fg" Color="#1C2630"/>
    <SolidColorBrush x:Key="Fg3" Color="#8A949E"/>
  </Window.Resources>
  <StackPanel Margin="24,20,24,14">
    <TextBlock Text="Crea la cartella in" FontWeight="SemiBold"/>
    <ComboBox x:Name="Dest" Width="250" HorizontalAlignment="Left" Margin="0,8,0,0">
      <ComboBoxItem Content="Scrivania"/>
      <ComboBoxItem Content="Documenti"/>
      <ComboBoxItem Content="Download"/>
      <ComboBoxItem Content="Altra cartella…"/>
    </ComboBox>
    <TextBlock x:Name="DestPath" FontSize="11" Margin="0,6,0,0" Foreground="{DynamicResource Fg3}" TextTrimming="CharacterEllipsis"/>
    <Separator Margin="0,14,0,14"/>
    <TextBlock Text="Dopo la creazione" FontWeight="SemiBold"/>
    <CheckBox x:Name="CbClose" Content="Chiudi l’app" Margin="0,8,0,0" Foreground="{DynamicResource Fg}"/>
    <CheckBox x:Name="CbReveal" Content="Mostra la cartella in Esplora file" Margin="0,8,0,0" Foreground="{DynamicResource Fg}"/>
    <Separator Margin="0,14,0,14"/>
    <TextBlock Text="File di partenza" FontWeight="SemiBold"/>
    <CheckBox x:Name="CbTemplate" Content="Inserisci un contenuto base nei file" Margin="0,8,0,0" Foreground="{DynamicResource Fg}"/>
    <TextBlock Text="Se disattivato, i file vengono creati vuoti." FontSize="11" Margin="20,4,0,0" Foreground="{DynamicResource Fg3}"/>
    <TextBlock Text="Le modifiche si salvano automaticamente." FontSize="11" Margin="0,16,0,0"
               HorizontalAlignment="Center" Foreground="{DynamicResource Fg3}"/>
  </StackPanel>
</Window>
'@

# ---------------------------------------------------------------------------
# Azioni
# ---------------------------------------------------------------------------

function Get-Bitmap([string]$Path) {
    $bi = New-Object System.Windows.Media.Imaging.BitmapImage
    $bi.BeginInit()
    $bi.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
    $bi.UriSource = [Uri]$Path
    $bi.EndInit()
    $bi.Freeze()
    return $bi
}

function Update-Caption {
    $script:UI.CaptionBtn.Content = 'Verrà creata in: ' + (Get-DestName) + '   ›'
}

function Invoke-Create {
    $name = Get-CleanName $script:UI.Field.Text
    if (-not $name) {
        $script:UI.ErrorLbl.Text = 'Scrivi un nome per la cartella'
        [void]$script:UI.Field.Focus()
        return
    }
    $script:UI.ErrorLbl.Text = ''

    $root = Join-Path (Get-DestPath) $name
    try {
        New-SiteFolder -Root $root -UseTemplate ([bool]$script:Settings.template) -TemplatesDir $script:Templates
    } catch {
        Write-Log "creazione fallita: $_"
        $script:UI.ErrorLbl.Text = 'Impossibile creare la cartella (controlla i permessi)'
        return
    }

    if ($script:Settings.reveal) { Start-Process -FilePath 'explorer.exe' -ArgumentList ('"{0}"' -f $root) }

    $script:UI.CreateBtn.Content = 'Creata  ✓'
    $script:UI.CreateBtn.IsEnabled = $false
    $t = New-Object System.Windows.Threading.DispatcherTimer
    $t.Interval = [TimeSpan]::FromMilliseconds(700)
    $t.Add_Tick({ $this.Stop(); Complete-Create })
    $t.Start()
}

function Complete-Create {
    if ($script:Settings.closeAfter) { $script:Win.Close(); return }
    $script:UI.CreateBtn.Content = 'Scatena'
    $script:UI.CreateBtn.IsEnabled = $true
    $script:UI.Field.Text = ''
    [void]$script:UI.Field.Focus()
}

function Sync-SettingsUI {
    if (-not $script:SettingsWin) { return }
    $script:Syncing = $true
    $idx = @{ desktop = 0; documents = 1; downloads = 2; custom = 3 }[[string]$script:Settings.dest]
    $script:SUI.Dest.SelectedIndex = if ($null -eq $idx) { 0 } else { $idx }
    $script:SUI.DestPath.Text = Get-DestPath
    $script:SUI.CbClose.IsChecked = [bool]$script:Settings.closeAfter
    $script:SUI.CbReveal.IsChecked = [bool]$script:Settings.reveal
    $script:SUI.CbTemplate.IsChecked = [bool]$script:Settings.template
    $script:Syncing = $false
}

function Invoke-DestChanged {
    $idx = $script:SUI.Dest.SelectedIndex
    if ($idx -eq 3) {
        $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
        $dlg.Description = 'Scegli dove creare la cartella del sito'
        $dlg.ShowNewFolderButton = $true
        if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            $script:Settings.customPath = $dlg.SelectedPath
            $script:Settings.dest = 'custom'
        }
    } elseif ($idx -ge 0) {
        $script:Settings.dest = @('desktop', 'documents', 'downloads')[$idx]
    }
    Save-Settings
    Sync-SettingsUI
    Update-Caption
}

function Invoke-PrefChanged {
    $script:Settings.closeAfter = [bool]$script:SUI.CbClose.IsChecked
    $script:Settings.reveal = [bool]$script:SUI.CbReveal.IsChecked
    $script:Settings.template = [bool]$script:SUI.CbTemplate.IsChecked
    Save-Settings
}

function New-SettingsWindow {
    $w = [System.Windows.Markup.XamlReader]::Parse($script:SettingsXaml)
    $ui = @{}
    foreach ($n in 'Dest', 'DestPath', 'CbClose', 'CbReveal', 'CbTemplate') { $ui[$n] = $w.FindName($n) }
    $script:SUI = $ui
    return $w
}

function Open-Settings {
    if ($script:SettingsWin -and $script:SettingsWin.IsVisible) { [void]$script:SettingsWin.Activate(); return }

    $w = New-SettingsWindow
    $script:SettingsWin = $w
    $w.Owner = $script:Win
    $w.Icon = $script:Win.Icon

    $script:SUI.Dest.Add_SelectionChanged({ if (-not $script:Syncing) { Invoke-DestChanged } })
    foreach ($c in 'CbClose', 'CbReveal', 'CbTemplate') { $script:SUI[$c].Add_Click({ Invoke-PrefChanged }) }
    $w.Add_SourceInitialized({ Set-TitleBar $script:SettingsWin (Test-DarkMode) })
    $w.Add_Closed({ $script:SettingsWin = $null })

    $p = if (Test-DarkMode) { $script:Palette.Dark } else { $script:Palette.Light }
    Set-ThemeResources $w $p
    Sync-SettingsUI
    $w.Show()
}

# ---------------------------------------------------------------------------
# Avvio
# ---------------------------------------------------------------------------

function Start-App {
    Initialize-Log
    Write-Log '1 avvio'
    Import-Settings

    $script:Assets = Find-Dir 'assets'
    $script:Templates = Find-Dir 'templates'

    $script:BgLight = Get-Bitmap (Join-Path $script:Assets 'bg_light.jpg')
    $script:BgDark = Get-Bitmap (Join-Path $script:Assets 'bg_dark.jpg')

    $script:Win = [System.Windows.Markup.XamlReader]::Parse($script:MainXaml)
    $ui = @{}
    foreach ($n in 'Bg', 'BgBlur', 'Logo', 'Field', 'Placeholder', 'ErrorLbl', 'CreateBtn', 'CaptionBtn', 'GearBtn') {
        $ui[$n] = $script:Win.FindName($n)
        if ($null -eq $ui[$n]) { throw "Elemento '$n' mancante nell'interfaccia" }
    }
    $script:UI = $ui
    Write-Log '2 finestra costruita'

    $ui.Logo.Source = Get-Bitmap (Join-Path $script:Assets 'icon.png')
    $script:Win.Icon = Get-Bitmap (Join-Path $script:Assets 'icon_dock.png')
    Update-Theme
    Update-Caption

    if ($SelfTest) {
        [void](New-SettingsWindow)      # verifica anche che il XAML delle impostazioni sia valido
        Write-Output 'SelfTest OK'
        return
    }

    $ui.CreateBtn.Add_Click({ Invoke-Create })
    $ui.CaptionBtn.Add_Click({ Open-Settings })
    $ui.GearBtn.Add_Click({ Open-Settings })
    $ui.Field.Add_TextChanged({
        $script:UI.Placeholder.Visibility = if ($script:UI.Field.Text) { 'Collapsed' } else { 'Visible' }
    })
    $script:Win.Add_PreviewKeyDown({
        param($sender, $e)
        if (([System.Windows.Input.Keyboard]::Modifiers -band [System.Windows.Input.ModifierKeys]::Control) -and $e.Key -eq 'OemComma') {
            Open-Settings
            $e.Handled = $true
        }
    })
    $script:Win.Add_SourceInitialized({ Set-TitleBar $script:Win (Test-DarkMode) })
    $script:Win.Add_ContentRendered({ [void]$script:UI.Field.Focus(); Write-Log '3 finestra mostrata' })

    # controlla ogni secondo se Windows è passato da chiaro a scuro (o viceversa)
    $timer = New-Object System.Windows.Threading.DispatcherTimer
    $timer.Interval = [TimeSpan]::FromSeconds(1)
    $timer.Add_Tick({ Update-Theme })
    $timer.Start()

    [void]$script:Win.ShowDialog()      # chiudere la finestra con la X = chiudere l'app
    Write-Log '4 chiusa'
}

# Finestra semplice di emergenza (usata solo se l'interfaccia completa non parte)
function Start-Fallback([string]$Detail) {
    $msg = "App in esecuzione`n`nInserisci nome cartella principale"
    if ($Detail) {
        if ($Detail.Length -gt 220) { $Detail = $Detail.Substring(0, 220) }
        $msg += "`n`n(modalità semplice: $Detail)"
    }
    $name = ''
    while (-not $name) {
        $raw = [Microsoft.VisualBasic.Interaction]::InputBox($msg, $script:AppName, '')
        if ([string]::IsNullOrEmpty($raw)) { return }       # Annulla
        $name = Get-CleanName $raw
    }
    New-SiteFolder -Root (Join-Path ([Environment]::GetFolderPath('Desktop')) $name) -UseTemplate $false -TemplatesDir ''
}

try {
    Start-App
} catch {
    Write-Log ("ERRORE: {0} | {1}" -f $_, $_.ScriptStackTrace)
    if ($SelfTest) { Write-Error $_; exit 1 }
    Start-Fallback $_.Exception.Message
}
